/**
 *
 * @author  Martijn Vermaat (mvermaat@cs.vu.nl)
 *          Rafiek Mohamedjoesoef (rmohame@cs.vu.nl)
 *
 * Sequence object contains a circular sequence and
 * provides methods for setting rotation, retreiving
 * reverse sequence, comparing with another sequence
 * object, etc.
 *
 */
public class Sequence {


    private String header, comment, sequence;
    private boolean reversed;
    private int rotation;


    public Sequence(String header, String comment, String sequence) {

        this.header = header;
        this.comment = comment;
        this.sequence = sequence;

        this.setReversed(false);
        this.setRotation(0);

    }


    public String getComment() {
        return comment;
    }


    public void setComment(String comment) {
        this.comment = comment;
    }


    public String getHeader() {
        return header;
    }


    public void setHeader(String header) {
        this.header = header;
    }


    /**
     * Returns sequence string respecting current rotation and reverse state.
     */
    public String getSequence() {

        String s = sequence;

        if (getReversed()) {
            s = new StringBuilder(sequence).reverse().toString();
        }

        return s.substring(rotation) + s.substring(0, rotation);

    }


    public void setSequence(String sequence) {
        this.sequence = sequence;
    }


    public int getLength() {
        return sequence.length();
    }


    public void setReversed(boolean r) {
        reversed = r;
    }


    public boolean getReversed() {
        return reversed;
    }


    public void setRotation(int n) {
        if (n >= 0 && n < getLength()) {
            rotation = n;
        }
    }


    public int getRotation() {
        return rotation;
    }


    /**
     * Returns this sequence reversed as new sequence
     */
    public Sequence getReverse() {

        String reverse = new StringBuilder(getSequence()).reverse().toString();

        return new Sequence(header, comment, reverse);

    }


    /**
     * Returns subsequence(from, to) as new sequence
     */
    public Sequence getSequence(int from, int to) {

        return new Sequence(header, comment, getSequence().substring(from, to));

    }


    /**
     * Check if this sequence is the same as the provided
     * sequence (possibly rotated and/or reversed).
     */
    public boolean equals(Sequence s) {

        boolean oldReversed = getReversed();
        int oldRotation = getRotation();

        setReversed(true);

        for (int n=0; n<getLength(); n++) {
            setRotation(n);
            if (getSequence().equals(s.getSequence())) {
                setReversed(oldReversed);
                setRotation(oldRotation);
                return true;
            }
        }

        setReversed(false);

        for (int n=0; n<getLength(); n++) {
            setRotation(n);
            if (getSequence().equals(s.getSequence())) {
                setReversed(oldReversed);
                setRotation(oldRotation);
                return true;
            }
        }

        setReversed(oldReversed);
        setRotation(oldRotation);
        return false;

    }


}
