/**
 *
 * @author  Martijn Vermaat (mvermaat@cs.vu.nl)
 *          Rafiek Mohamedjoesoef (rmohame@cs.vu.nl)
 *
 * Matrix holds the (a) maximum global alignment score for two
 * sequences. The score is calculated using a pre-defined exchange
 * matrix.
 * It is also possible to retreive the row values from the
 * alignments.
 * The Matrix is implemented using O(n) space, lazy calculating
 * just what is needed and only remembering the last two rows.
 *
 */
public class Matrix {

   
    private static final int BASE_A = 0;
    private static final int BASE_C = 1;
    private static final int BASE_G = 2;
    private static final int BASE_T = 3;

    private static final int identity[][] = {
        {1, -2, -2, -2},
        {-2, 1, -2, -2},
        {-2, -2, 1, -2},
        {-2, -2, -2, 1}
    };

    private static final int GAP = 3;

    private Sequence horizontal, vertical;

    private int currentRowPosition;
    private int[] previousRow, currentRow;


    public Matrix(Sequence horizontal, Sequence vertical) {

        previousRow = new int[horizontal.getLength()+1];
        currentRow = new int[horizontal.getLength()+1];

        // Nothing calculated yet
        currentRowPosition = -1;

        this.horizontal = horizontal;
        this.vertical = vertical;

    }


    public int getScore() {

        // We are forced to calculate up to the bottom row
        calculateRow(vertical.getLength());
        return currentRow[horizontal.getLength()];

    }


    public int[] getRow(int i) {

        // We have to calculate the row first
        calculateRow(i);
        return currentRow;

    }


    /**
     * Calculate the values of the given row. We only calculate
     * from the point we already have calculated, so no work is
     * thrown away.
     * Except for the case we calculated a row positioned lower
     * than this row. Then we have to start over from the top.
     */
    private void calculateRow(int row) {

        // Don't run out of the Matrix
        if (row > vertical.getLength()) {
            row = vertical.getLength();
        }

        // Calculate forward, or start over?
        if (row < currentRowPosition) {
            // Calculation is not so smart...
            // Try calling methods in a different order ;)
            currentRowPosition = -1;
        }

        while (currentRowPosition < row) {

            copyArray(currentRow, previousRow);
            currentRowPosition++;

            for (int i=0; i<=horizontal.getLength(); i++) {
                currentRow[i] = calculateCell(i);
            }

        }

    }


    private void copyArray(int[] from, int[] to) {
        for(int i=0; i<from.length; i++) {
            to[i] = from[i];
        }
    }


    /**
     * Calculate the value for the cell in the current row
     * and given column.
     * Do this using top, top-left, and left neighbours.
     */
    private int calculateCell(int column) {

        int topleft, top, left;

        if (currentRowPosition == 0 && column==0) {
            // Init coordinate (0,0)
            return 0;
        }
        
        if (currentRowPosition == 0) {
            // Introduce gap
            return currentRow[column-1] - GAP;
        }

        if (column == 0) {
            // Introduce gap
            return previousRow[0] - GAP;
        }

        topleft = previousRow[column - 1];
        topleft += match(horizontal.getSequence().charAt(column - 1),
                         vertical.getSequence().charAt(currentRowPosition - 1));

        top = previousRow[column] - GAP;

        left = currentRow[column-1] - GAP;

        return Math.max(topleft, Math.max(top, left));

    }


    /**
     * Do a lookup in the identity matrix.
     */
    private int match(char c1, char c2) {       
        return identity[baseToInt(c1)][baseToInt(c2)];
    }


    private int baseToInt(char c) {

        if(c == 'A') return BASE_A;
        if(c == 'C') return BASE_C;
        if(c == 'G') return BASE_G;
        if(c == 'T') return BASE_T;

        // This should never happen
        throw new RuntimeException("Could not convert base to int value");

    }


}
