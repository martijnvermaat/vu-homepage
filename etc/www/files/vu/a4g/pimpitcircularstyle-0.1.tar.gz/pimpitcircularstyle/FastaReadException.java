/**
 *
 * @author  Martijn Vermaat (mvermaat@cs.vu.nl)
 *          Rafiek Mohamedjoesoef (rmohame@cs.vu.nl)
 *
 * Exception thrown by FastaFile methods, needs
 * nothing special.
 *
 */
public class FastaReadException extends Exception {


    FastaReadException(String message) {
        super(message);
    }


}
