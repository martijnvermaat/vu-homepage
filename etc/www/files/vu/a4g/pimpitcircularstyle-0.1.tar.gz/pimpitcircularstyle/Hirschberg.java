/**
 *
 * @author  Martijn Vermaat (mvermaat@cs.vu.nl)
 *          Rafiek Mohamedjoesoef (rmohame@cs.vu.nl)
 *
 * Implements the Hirschberg algorithm which is optimized
 * for space efficiency.
 * Given two circular sequences, a global circular
 * alignment in constructed.
 *
 */
public class Hirschberg {


    private Sequence shortSequence, longSequence;
    private Matrix matrix;
    private Alignment alignment;

    private boolean orderHasChanged = false;


    public Hirschberg(Sequence s1, Sequence s2) {

        if (s1.getLength() <= s2.getLength()) {
            shortSequence = s1;
            longSequence = s2;
        } else {
            shortSequence = s2;
            longSequence = s1;
            orderHasChanged = true;
        }

        // Find out wat rotation gives best score (and possibly reverse)
        setRotation();

        // Construct the global circular alignment
        alignment = new Alignment(shortSequence, longSequence);

        pimp(shortSequence, longSequence);

    }


    public Alignment getAlignment() {
        return alignment;
    }


    public boolean orderChanged() {
        return orderHasChanged;
    }


    /**
     * Rotating the shortest sequence, calculate the highest
     * alignment score for each rotation. Keep the rotation
     * yielding the highest score.
     * Reversing the sequence is also considered.
     */
    private void setRotation() {

        boolean bestReversed = false;
        int bestScore = Integer.MIN_VALUE;
        int bestRotation = 0;

        shortSequence.setReversed(false);

        for (int i=0; i<shortSequence.getLength(); i++) {

            shortSequence.setRotation(i);

            matrix = new Matrix(shortSequence, longSequence);

            if (matrix.getScore() > bestScore) {
                bestScore = matrix.getScore();
                bestReversed = false;
                bestRotation = i;
            }

        }       

        shortSequence.setReversed(true);

        for (int i=0; i<shortSequence.getLength(); i++) {

            shortSequence.setRotation(i);

            matrix = new Matrix(shortSequence, longSequence);

            if (matrix.getScore() > bestScore) {
                bestScore = matrix.getScore();
                bestReversed = true;
                bestRotation = i;
            }

        }       

        shortSequence.setReversed(bestReversed);
        shortSequence.setRotation(bestRotation);

    }


    /**
     * Recursive function implementing the Hirschberg algorithm which
     * is optimized for space efficiency.
     */
    public void pimp(Sequence horizontal, Sequence vertical) {

        // No horizontal steps left
        if (horizontal.getLength() < 1) {
            for (int i=0; i<vertical.getLength(); i++) {
                alignment.pushFirstGap();
                alignment.pushSecondBase(vertical.getSequence().charAt(i));
            }
            return;
        }

        // No vertical steps left
        if (vertical.getLength() < 1) {
            for (int i=0; i<horizontal.getLength(); i++) {
                alignment.pushFirstBase(horizontal.getSequence().charAt(i));
                alignment.pushSecondGap();
            }
            return;
        }

        // Only one vertical step left
        if (vertical.getLength() < 2) {
            /*
              TODO:
              We construct here an alignment of some horizontal bases with one
              vertical base (match if that base is somewhere in the horizontal
              sequence, mismatch otherwise).
              The flaw is that we assume two gaps are more expensive than one
              mismatch (reasonable, but not necessarily true).
              The other option is to align the vertical base with an extra gap
              after the vertical bases (which is correct if two gaps are less
              expensive than one mismatch).
              Can we somehow change the algorithm to get rid of this stop
              condition?
            */
            for (int i=0; i<horizontal.getLength(); i++) {
                alignment.pushFirstBase(horizontal.getSequence().charAt(i));
                if (horizontal.getSequence().indexOf(vertical.getSequence()) == i
                    || (horizontal.getSequence().indexOf(vertical.getSequence()) == -1
                        && i == horizontal.getLength() - 1)) {
                    alignment.pushSecondBase(vertical.getSequence().charAt(0));
                } else {
                    alignment.pushSecondGap();
                }
            }
            return;
        }

        // Construct a matrix for the alignment and a matrix for the backwards
        // alignment
        Matrix forwardMatrix = new Matrix(horizontal, vertical);
        Matrix backwardMatrix = new Matrix(horizontal.getReverse(), vertical.getReverse());

        // unique middle or highest middle
        int forward_middle = (vertical.getLength() + 1) / 2;

        // unique middle + 1 or highest middle (same row as forward_middle)
        //int backward_middle = (vertical.getLength() + 2) / 2;

        // unique middle + 2 or highest middle + 1 (one row higher as forward_middle)
        // use this or above?
        // ok, rationale for using this one:
        //   best k combines best alignment of 0-mid with best alignment of mid-len
        //   where the first does not include mid and the second does
        //   so here, the backward matrix does 0-mid excluding mid and the forward
        //   matrix does mid-len including m
        // still not sure if this is really the right thing to do though, however the
        // above approach (both include mid) seems to give trouble all the time...
        int backward_middle = ((vertical.getLength() + 2) / 2) - 1;

        int[] forwardRow = forwardMatrix.getRow(forward_middle);
        int[] backwardRow = backwardMatrix.getRow(backward_middle);

        int bestValue = Integer.MIN_VALUE;
        int bestK = 0;
        int value;

        // Now choose a position k in the middle row so that the optimal path
        // crosses this k.
        // This is the case if the values forward to k and backward to k added
        // yield the optimal score for the total alignment.
        for (int k=0; k<forwardRow.length; k++) {

            value = forwardRow[k] + backwardRow[backwardRow.length - 1 - k];
            if (value > bestValue) {
                bestValue = value;
                bestK = k;
            }

        }

        // Recursive call for upper left area of matrix up to and including k
        pimp(horizontal.getSequence(0, bestK),
             vertical.getSequence(0, forward_middle));

        // Recursive call for lower right area of matrix from and including k
        pimp(horizontal.getSequence(bestK, horizontal.getLength()),
             vertical.getSequence(forward_middle, vertical.getLength()));

    }


}
