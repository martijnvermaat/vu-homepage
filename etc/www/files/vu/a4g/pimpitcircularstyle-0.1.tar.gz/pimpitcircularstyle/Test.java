import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;


/**
 * This is a very simple testing framework.
 * 
 *   Usage: java Test tests/tests.index
 *
 * tests.index is a file containing names of tests. For each
 * name <test_name>, Hirschberg is executed on two files:
 *
 *   <test_name>-a.fasta
 *   <test_name>-b.fasta
 *
 * The resulting alignment is compared to the alignment read
 * from the <test_name>.out file.
 *
 * TODO:
 *   On failure, no further information is provided.
 */
public class Test {


    private static final char START_COMMENT_CHAR = '#';


    public static void main(String[] args) {

        String testName;
        boolean testResult;

        String testDir = "tests/";

        BufferedReader input = null;

        int passed = 0;
        int failed = 0;
        int ignored = 0;

        if (args.length != 1) {
            System.out.println("Usage: java Test <file>");
            System.out.println("\tfile:\tfile with tests to run");
            System.exit(1);
        }

        try {

            input = new BufferedReader(new FileReader(args[0]));

            while (!(testName = readTestName(input)).equals("")) {

                if (testName.charAt(0) == START_COMMENT_CHAR) {
                    System.out.println(". ignored " + testName.substring(1).trim());
                    ignored++;
                    continue;
                }

                testResult = test(testDir + testName + "-a.fasta",
                                  testDir + testName + "-b.fasta",
                                  testDir + testName + ".out");

                if (testResult) {
                    System.out.println("  passed " + testName);
                    passed++;
                } else {
                    System.out.println("! failed " + testName);
                    failed++;
                }

            }
        } catch (FileNotFoundException e) {
            error(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            error("oops");
        } finally {
            try {
                if (input!= null) {
                    // Close BufferedReader and FileReader
                    input.close();
                }
            } catch (IOException ex) {
                // Do nothing
            }
        }

        System.out.println();
        System.out.println("Number of tests: " + (passed + failed + ignored));
        System.out.println("Tests ignored:   " + ignored);
        System.out.println("Tests passed:    " + passed);
        System.out.println("Tests failed:    " + failed);

    }


    private static boolean test(String fileIn1, String fileIn2, String fileOut) {

        FastaFile file1, file2;
        Alignment expected;
        String a1, a2;

        Hirschberg hb;
        BufferedReader input = null;

        try {
            file1 = new FastaFile(fileIn1);
        } catch (FastaReadException e) {
            error(e.getMessage());
            return false;
        }

        try {
            file2 = new FastaFile(fileIn2);
        } catch (FastaReadException e) {
            error(e.getMessage());
            return false;
        }

        if (file1.getLength() < 1) {
            error(fileIn1 + " (no sequences found)");
        }

        if (file2.getLength() < 1) {
            error(fileIn2 + " (no sequences found)");
        }

        hb = new Hirschberg(file1.getSequence(0),
                            file2.getSequence(0));

        // Hirschberg changed order of sequences, we should do so too
        if (hb.orderChanged()) {
            expected = new Alignment(file2.getSequence(0),
                                     file1.getSequence(0));
        } else {
            expected = new Alignment(file1.getSequence(0),
                                     file2.getSequence(0));
        }

        try {
            input = new BufferedReader(new FileReader(fileOut));
            a1 = readAlignment(input);
            a2 = readAlignment(input);
            if (hb.orderChanged()) {
                expected.setAlignment(a2, a1);
            } else {
                expected.setAlignment(a1, a2);
            }
        } catch (FileNotFoundException e) {
            error(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            error("oops");
        } finally {
            try {
                if (input!= null) {
                    // Close BufferedReader and FileReader
                    input.close();
                }
            } catch (IOException ex) {
                // Do nothing
            }
        }

        return (hb.getAlignment().equals(expected));

    }


    private static String readAlignment(BufferedReader input) throws IOException {

        String alignment = "";

        while ((alignment = input.readLine()) != null) {
            alignment = alignment.trim();
            if (!alignment.equals("")) break;
        }

        if (alignment == null) {
            throw new IOException("Could not read alignment from file");
        }

        return alignment;

    }


    private static String readTestName(BufferedReader input) throws IOException {

        String name = "";

        try {
            while ((name = input.readLine()) != null) {
                name = name.trim();
                if (!name.equals("")) break;
            }
        } catch (IOException ex){
            name = "";
        }

        if (name == null) name = "";

        return name;

    }


    private static void error(String e) {
        System.err.println("error: " + e);
        System.exit(1);
    }


}
