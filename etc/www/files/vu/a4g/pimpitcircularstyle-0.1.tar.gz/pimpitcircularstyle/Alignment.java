/**
 *
 * @author  Martijn Vermaat (mvermaat@cs.vu.nl)
 *          Rafiek Mohamedjoesoef (rmohame@cs.vu.nl)
 *
 * Represents a global circular alignment of two sequences.
 *
 */
public class Alignment {


    private static final char GAP_CHARACTER = '-';

    private static final int MATCH_SCORE = 1;
    private static final int MISMATCH_SCORE = -2;
    private static final int GAP_SCORE = -3;


    private Sequence sequence1, sequence2;
    private String alignment1, alignment2;


    public Alignment(Sequence s1, Sequence s2){

        sequence1 = s1;
        sequence2 = s2;

        alignment1 = "";
        alignment2 = "";

    }


    public Sequence getFirstSequence() {
        return sequence1;
    }


    public Sequence getSecondSequence() {
        return sequence2;
    }


    public String getFirstSequenceAligned() {
        return alignment1;
    }


    public String getSecondSequenceAligned() {
        return alignment2;
    }


    /**
     * Add a base to the alignment for first sequence.
     */
    public void pushFirstBase(char b) {
        alignment1 += b;
    }


    /**
     * Add a base to the alignment for second sequence.
     */
    public void pushSecondBase(char b) {
        alignment2 += b;
    }


    /**
     * Add a gap to the alignment for first sequence.
     */
    public void pushFirstGap() {
        alignment1 += GAP_CHARACTER;
    }


    /**
     * Add a gap to the alignment for second sequence.
     */
    public void pushSecondGap() {
        alignment2 += GAP_CHARACTER;
    }


    /**
     * Check if the alignment is valid for the two
     * sequences. Their length must be the same, they
     * must contain only base letters or gap characters
     * and must encode exactly for the two sequences.
     */
    public boolean isValid() {

        String bases = "ATCG";
        String validChars = bases + GAP_CHARACTER;

        String constructed1 = "";
        String reverseConstructed1 = "";
        String constructed2 = "";
        String reverseConstructed2 = "";

        boolean match1 = false;
        boolean match2 = false;

        if (alignment1.length() != alignment2.length()) {
            return false;
        }

        for (int i=0; i<alignment1.length(); i++) {
            if (validChars.indexOf(alignment1.charAt(i)) == -1
                || validChars.indexOf(alignment2.charAt(i)) == -1) {
                return false;
            }
            if (bases.indexOf(alignment1.charAt(i)) != -1) {
                constructed1 += alignment1.charAt(i);
            }
            if (bases.indexOf(alignment2.charAt(i)) != -1) {
                constructed2 += alignment2.charAt(i);
            }
        }

        // We also compare against reversed sequence
        reverseConstructed1 = new StringBuilder(constructed1).reverse().toString();
        reverseConstructed2 = new StringBuilder(constructed2).reverse().toString();

        for (int i=0; i<constructed1.length(); i++) {
            if (sequence1.getSequence().equals(
                    constructed1.substring(i) + constructed1.substring(0, i))) {
                match1 = true;
                break;
            }
            if (sequence1.getSequence().equals(
                    reverseConstructed1.substring(i) + reverseConstructed1.substring(0, i))) {
                match1 = true;
                break;
            }
        }

        for (int i=0; i<constructed2.length(); i++) {
            if (sequence2.getSequence().equals(
                    constructed2.substring(i) + constructed2.substring(0, i))) {
                match2 = true;
                break;
            }
            if (sequence2.getSequence().equals(
                    reverseConstructed2.substring(i) + reverseConstructed2.substring(0, i))) {
                match2 = true;
                break;
            }
        }

        return (match1 && match2);

    }


    /**
     * Two alignments are equal if they are valid encodings
     * for the same two sequences and yield the same score.
     */
    public boolean equals(Alignment a) {

        if (!isValid() || !a.isValid()) {
            return false;
        }

        if (!sequence1.equals(a.sequence1)
            || !sequence2.equals(a.sequence2)) {
            return false;
        }

        return (getScore() == a.getScore());

    }


    public int getScore() {

        int score = 0;

        if (!isValid()) {
            return Integer.MIN_VALUE;
        }

        for (int i=0; i<alignment1.length(); i++) {
            if (alignment1.charAt(i) == GAP_CHARACTER) {
                score += GAP_SCORE;
            } else if (alignment2.charAt(i) == GAP_CHARACTER) {
                score += GAP_SCORE;
            } else if (alignment1.charAt(i) == alignment2.charAt(i)) {
                score += MATCH_SCORE;
            } else {
                score += MISMATCH_SCORE;
            }
        }

        return score;

    }


    public void setAlignment(String a1, String a2) {

        alignment1 = a1;
        alignment2 = a2;

    }


}
