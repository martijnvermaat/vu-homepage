/**
 *
 * PimpItCircularStyle
 *
 * Version 0.1, 2005-11-21
 *
 * Martijn Vermaat (mvermaat@cs.vu.nl)
 * Rafiek Mohamedjoesoef (rmohame@cs.vu.nl)
 *
 * Reads two circular sequences from Fasta files and
 * prints the (a) best global circular alignment and
 * the score of the alignment.
 *
 * Usage: java PimpItCircularStyle <file1> <file2>
 *  file1: File containing sequence in Fasta format
 *  file2: File containing sequence in Fasta format
 *
 * See the file "LICENSE" for copyright information and
 * the terms and conditions for copying, distribution
 * and modification of this program.
 *
 */
public class PimpItCircularStyle {


    public static void main(String[] args) {

        FastaFile file1, file2;
        Hirschberg hb;

        if (args.length != 2) {
            printHelp();
            System.exit(1);
        }

        try {
            file1 = new FastaFile(args[0]);
        } catch (FastaReadException e) {
            error(e.getMessage());
            return;
        }

        try {
            file2 = new FastaFile(args[1]);
        } catch (FastaReadException e) {
            error(e.getMessage());
            return;
        }

        if (file1.getLength() < 1) {
            error(args[0] + " (no sequences found)");
        }

        if (file2.getLength() < 1) {
            error(args[1] + " (no sequences found)");
        }

        hb = new Hirschberg(file1.getSequence(0),
                            file2.getSequence(0));

        System.out.println(hb.getAlignment().getScore());

        if (hb.orderChanged()) {
            System.out.println(hb.getAlignment().getSecondSequenceAligned());
            System.out.println(hb.getAlignment().getFirstSequenceAligned());
        } else {
            System.out.println(hb.getAlignment().getFirstSequenceAligned());
            System.out.println(hb.getAlignment().getSecondSequenceAligned());
        }

    }


    private static void error(String e) {
        printHelp();
        System.err.println("error: " + e);
        System.exit(1);
    }


    private static void printHelp() {
        System.out.println(
            "Usage: java PimpItCircularStyle <file1> <file2>");
        System.out.println("\tfile1:\tFile containing sequence in Fasta format");
        System.out.println("\tfile2:\tFile containing sequence in Fasta format");
    }


}
