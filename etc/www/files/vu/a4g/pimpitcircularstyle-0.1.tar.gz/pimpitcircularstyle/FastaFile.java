import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Vector;


/**
 *
 * @author  Martijn Vermaat (mvermaat@cs.vu.nl)
 *          Rafiek Mohamedjoesoef (rmohame@cs.vu.nl)
 *
 * Reads a file in Fasta format and stores all sequences
 * contained in the file.
 *
 */
public class FastaFile {


    private static final int MAX_LINE_LENGTH = 200;
    private static final char HEADER_START_CHAR = '>';
    private static final char COMMENT_START_CHAR = ';';


    private Vector<Sequence> sequences;
    static int ch;

    BufferedReader input = null;


    public FastaFile(String fileName) throws FastaReadException{

    	try {
            input = new BufferedReader(new FileReader(fileName));
    		sequences = readFastaFile(input);
        } catch (FileNotFoundException e) {
            throw new FastaReadException(e.getMessage());
        } catch (IOException e) {
			e.printStackTrace();
        } finally {
            try {
                if (input!= null) {
                    // Close BufferedReader and FileReader
                    input.close();
                }
            } catch (IOException ex) {
                // Do nothing
            }
        }

    } 


    public int getLength() {
        return sequences.size();
    }


    public Sequence getSequence(int n) {

        // This is of course not safe (0 <= n < size)
        return sequences.elementAt(n);

    }


    /**
     * Reads the headers, comments and sequences from input.
     * Returns a vector containing all sequences in the file.
     * Input is a fasta file.
     * @throws IOException
     */
    private static Vector<Sequence> readFastaFile(BufferedReader input) throws IOException {

        Vector<Sequence> v = new Vector<Sequence>();
        Sequence s;

        while ((s = readSequence(input)) != null) {
            v.add(s);
        }

        v.trimToSize();
        
        return v;

    }


    private static Sequence readSequence(BufferedReader input) throws IOException {

        String header, comment, sequence; 

        header = readHeader(input);
        if (header == null){ return null; }
        
        comment = readComment(input);
        if (comment == null){ return null; }

        sequence = readSequenceString(input);
        if (sequence == null){ return null; }        

        return new Sequence(header, comment, sequence);

    }


    /**
     * Reads all bases for the sequence and returns it as a String.
     * @throws IOException
     */
    private static String readSequenceString(BufferedReader input) throws IOException {

        String sequence = null;
        String line;

        input.mark(MAX_LINE_LENGTH);

        while ((line = input.readLine()) != null) {

            line = line.trim();

            if (line.charAt(0) == HEADER_START_CHAR) {
                input.reset();
                break;
            }

            if (sequence == null) sequence = "";
            sequence += line;

            input.mark(MAX_LINE_LENGTH);

        }

        return sequence;

    }


    /**
     * Reads the comment and returns it as a String.
     * @throws IOException
     */
    private static String readComment(BufferedReader input) throws IOException{

        input.mark(2);
	    if (input.read() != COMMENT_START_CHAR) {
            // Comment expected
	    	input.reset();
	    	return " ";
		}

        String comment = input.readLine();

        if (comment != null) comment = comment.trim();

    	return comment;

    }


    /**
     * Reads the header and returns it as a String.
     * @throws IOException
     */
    private static String readHeader(BufferedReader input) throws IOException{

        input.mark(2);
	    if (input.read() != HEADER_START_CHAR) {
            // Header expected
	    	input.reset();
	    	return " ";
		}

        String header = input.readLine();

        if (header != null) header = header.trim();

    	return header;

    }


}
