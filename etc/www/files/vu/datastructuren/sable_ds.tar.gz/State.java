class State implements StateInterface {


    Lijst state;


    State() {
        init();
    }


    public void init() {
        state = new Lijst();
    }


    public Set get(Identifier identifier) {

        if (state.find(new Assignment(identifier, new Set()))) {
            return ((Assignment) state.retrieve()).getSet();
        } else {
            return null;
        }

    }


    public void put(Identifier identifier, Set set) {

        if (state.find(new Assignment(identifier, set))) {
            state.remove();
        }

        state.insert(new Assignment(identifier, set));

    }


    public String toString() {

        String s = "State<";

        if (state.setFirst()) {
            s += state.retrieve().toString();
            while (state.getNext()) {
                s += "," + state.retrieve().toString();
            }
        }

        return s + ">";

    }


    public boolean equals(Object rhs) {

        if (!(rhs instanceof State)) {
            return false;
        }

        return state.equals( ((State) rhs).state );

    }


    public Object clone() throws CloneNotSupportedException {

        State clone = (State) super.clone();

        clone.state = (Lijst) state.clone();

        return clone;

    }


}
