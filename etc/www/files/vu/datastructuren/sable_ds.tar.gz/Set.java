public class Set implements SetInterface {


    Lijst elements ;

        
    Set() {
        init();
    }
    

    public Set init() {
        elements = new Lijst();
        return this;
    }


    public String toString() {
        return elements.toString();
    }


    public Set add(Data data) {
        if (!elements.find(data)) {
            elements.insert(data);
        }
        return this;
    }


    public int size() {
        return elements.size();
    }


    public boolean isEmpty() {
        return elements.isEmpty();
    }


    public Data remove() {
        elements.setFirst();
        Data result = (Data) elements.retrieve();
        elements.remove();
        return result;
    }


    public Object clone() {
        try {
            Set clone = (Set) super.clone();
            clone.elements = (Lijst) elements.clone();
            return clone;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }


    public static Set union(Set setA, Set setB) {

        Set result = (Set) setA.clone();

        if (setB.elements.setFirst()) {

            do {
                result.add(setB.elements.retrieve());
            } while (setB.elements.getNext());
        }

        return result;

    }


    public static Set difference(Set setA, Set setB) {

        Set result = (Set) setA.clone();

        if (setB.elements.setFirst()) {

            do {

                if (result.elements.find(setB.elements.retrieve())) {
                    result.elements.remove();
                }

            } while (setB.elements.getNext());
        }

        return result;
        
    }


    public static Set crossSection(Set setA, Set setB) {

        Set result = new Set();

        if (setA.elements.setFirst()) {

            do {

                if (setB.elements.find(setA.elements.retrieve())) {
                    result.add( setA.elements.retrieve() );
                }

            } while (setA.elements.getNext());
        }
         
        return result;

    }


    public static Set symmetricDifference(Set setA, Set setB) {

        return union(difference(setA, setB), difference(setB, setA));

    }


}
