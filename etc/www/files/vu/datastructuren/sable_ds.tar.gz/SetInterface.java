public interface SetInterface extends Cloneable {


    /*
      Elements  : [Data] objects
      Structure : none
      Domain    : any number of [Data] objects.
    */




    /*

      Constructors
        
      Collection();
      PRE  -
      POST - New [Collection] object is created with no elements

    */


    Set init();
    /*
      PRE  -
      POST - [this] is initialized and returned, no elements exist
    */

    String toString();
    /*
      PRE  -
      POST - A String representation of [this] is returned
    */

    Set add(Data data);
    /*
      PRE  -
      POST - An [Data] object equal to [Data] is present as element
             and [this] is returned
    */

    int size();
    /*
      PRE  -
      POST - Number of elements is returned
    */

    boolean isEmpty();
    /*
      PRE  -
      POST - Returns [true] if number of elements is 0, otherwise returns [false]
    */

    Data remove();
    /*
      PRE  - [this] is not empty
      POST - One of the elements is returned, no copy of it exists as element
    */

/*
    static Set union(Set setA, Set setB);
    
      PRE  -
      POST - New [Set] object is returned with copies of all elements of [setA] and [setB]
                 

    static Set difference(Set setA, Set setB);
    
      PRE  -
      POST - New [Set] object is returned with copies of all elements of [setA] minus all elements of [setB]
    

    static Set crossSection(Set setA, Set setB);
    
      PRE  -
      POST - New [Set] object is returned with copies off all elements that are in both [setA] and [setB]
    

    static Set symmetricDifference(Set setA, Set setB);
    
      PRE  -
      POST - New [Set] object is returned with copies all elements of [difference(setA, setB)] and
             copies of all elements of [difference(setB, setA)]
*/


}    
