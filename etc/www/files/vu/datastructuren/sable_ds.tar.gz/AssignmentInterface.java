interface AssignmentInterface extends Data {


    /*
      Elements   : [Identifier] and [Set] object
      Structure  : none
      Domain     : One [Identifier] and one [Set] object
    */


    /*

      Constructors:
      
      Assignment();
      PRE  - 
      POST - a new [Assignment] object is created.

      Assignment(Identifier identifier, Set set);
      PRE  -
      POST - a new [Assignment] object is created with copy of [identifier] and [set]
    */


    Assignment init(Identifier identifier, Set set);
    /*
      PRE  - 
      POST - a new [Assignment] object is created with copy of [identifier] and [set], [this]-POST is returned.
    */

    String toString();
    /*
      PRE  -
      POST - a [String] representation of [this] is returned
    */

    Set getSet();
    /*
      PRE  - 
      POST - a copy of [set] object is returned
    */

    Identifier getIdentifier();
    /*
      PRE  -
      POST - a copy of [identifer] object is returned
    */
}
