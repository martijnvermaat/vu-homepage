class NaturalNumber implements NaturalNumberInterface {



    public static final char DEFAULT_CHAR = '0';
    private String nn;



    NaturalNumber() {
        init(DEFAULT_CHAR);
    }


    NaturalNumber(char c) {
      init(c);
    }


    public NaturalNumber init(char c) {
        nn = ""+c;
        return this;
    }
    

    public String toString() {
        return nn;
    }

    
    public char getChar(int i) {
        return nn.charAt(i);
    }
    

    public NaturalNumber addChar(char c) {
        if(nn.equals("0")) {
            nn = ""+c;
        } else {
            nn += c;
        }
        return this;
    }


    public int size() {
        return nn.length();
    }
    

    public String getAll() {
        return nn;
    }


    public boolean equals(Object rhs) {
        if ( !(rhs instanceof NaturalNumber)) {
            return false;
        }
        return nn.equals( ((NaturalNumber)rhs).nn );
    }


    public int compareTo(Object rhs) {
        if(!(rhs instanceof NaturalNumber)) {
            throw new ClassCastException("NaturalNumber expected");
        }
        if (nn.length() == ((NaturalNumber)rhs).nn.length()) {
            return nn.compareTo( ((NaturalNumber)rhs).nn );
        } else {
            return nn.length() > ((NaturalNumber)rhs).nn.length() ? 1 : -1;
        }
    }


    public Object clone() {
        try {
            NaturalNumber clone = (NaturalNumber) super.clone();
            clone.nn = nn;
            return clone;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }


}
