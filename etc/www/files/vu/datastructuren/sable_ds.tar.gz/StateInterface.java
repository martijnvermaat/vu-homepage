interface StateInterface extends Cloneable {

    /*
      Elements   : Couples of [Identifier] and [Set] objects
      Structure  : none
      Domain     : any number of couples where identifier are unique.
    */



    /*
      Constructor:
      
      State();
      PRE  -
      POST - a new [State] object is created with no elements

      
    */


    void init();
    /*
      PRE  -
      POST - [this]-POST contains no elements.
    */
    

    Set get(Identifier identifier);
    /*
      PRE  -
      POST - If a couple with equal identifier is found, a copy 
             of the [Set] object associated with this couple is returned.
             If no such couple is found, [null] is returned. 
    */

    void put(Identifier identifier, Set set);
    /*
      PRE  -
      POST - a new couple, containing copies of [identifier] and [set] is added to [this].  
             When [State]-object allready contains occurence equal to [identifier], the 
             [Set]-object is overwritten with a copy of [set].
    */

    String toString();
    /*
      PRE  -
      POST - a [String] representation of [this] is returned,
    */
}
