interface NaturalNumberInterface extends Data {


    /*
      Elements    : Digits of type [char]
      Structure   : Linear
      Domain      : One zero digit or one or more digits where the first is not zero
    */


    /*

      Constructors

      NaturalNumber();
      PRE  - 
      POST - New NaturalNumber object is created with one element: '0'

      NaturalNumber(char c);
      PRE  - [c] is a digit
      POST - New NaturalNumber object is created with one element: [c]

    */


    NaturalNumber init(char c);
    /*
      PRE  - [c] is a digit
      POST - [c] is only element of [this]-post, [this]-POST is returned.
    */

    String toString();
    /*
      PRE  - 
      POST - a [String] representation of [this] is returned.
    */

    char getChar(int i);
    /*
      PRE  - 0 <= [i] < [numberOfElements]
      POST - Element on position [i] is returned
    */

    NaturalNumber addChar(char c);
    /*
      PRE  - Only element of [this] is not 'zero' and [c] is a digit
      POST - Element [c] is added as last digit of [this], [this]-post is returned.
    */

    int size();
    /*
      PRE  -
      POST - number of elements of [this] is returned 
    */

    boolean equals(Object rhs);
    /*
      PRE  -
      POST - TRUE  : elements of [rhs] equal elements of [this] 
             FALSE : otherwise
    */

}
