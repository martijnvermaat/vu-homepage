class Lijst implements LijstInterface {


    private Knoop first;
    private Knoop last;
    private Knoop current;
    private int size;


    Lijst () {

        init();

    }


    public boolean isEmpty () {

        return size == 0;

    }


    public Lijst init () {

        first = last = current = null;
        size = 0;

        return this;

    }


    public int size () {

        return size;

    }


    public Lijst insert (Data d) {

        if (isEmpty()) {

            // list is empty

            first = last = current = new Knoop(d, null, null);

            size = 1;

            return this;

        }

        if (d.compareTo(first.data) < 0) {

            // add before first

            current = first = first.prior = new Knoop(d, null, first);

            size++;

            return this;

        }

        if (d.compareTo(last.data) > 0) {

            // add after last

            current = last = last.next = new Knoop(d, last, null);

            size++;

            return this;

        }

        // add after current (current is not last)

        find(d);

        current = current.next = current.next.prior = new Knoop(d, current, current.next);

        size++;

        return this;

    }


    public Data retrieve () {

        return (Data) current.data.clone();

    }


    public Lijst remove () {

        if (size() == 1) {

            current = first = last = null;
            size--;

            return this;

        }

        if (current == first) {

            current = first = first.next;
            current.prior = null;
            size--;

            return this;

        }


        if (current == last) {

            current = last = last.prior;
            current.next = null;
            size--;

            return this;

        }

        current.next.prior = current.prior;
        current = current.prior.next = current.next;
        size--;

        return this;

    }


    public boolean find (Data d) {

        if (isEmpty()) {
            return false;
        }

        Knoop stop = null;

        if (d.compareTo(current.data) <= 0) {
            stop = current.next;
            current = first;
        }

        while (current.next != stop && d.compareTo(current.next.data) >= 0) {
            current = current.next;
        }

        if (d.compareTo(first.data) < 0) {
            return false;
        }

        if (d.compareTo(last.data) > 0) {
            return false;
        }

        return (d.compareTo(current.data) == 0);

    }


    public boolean setFirst () {

        if (isEmpty()) {
            return false;
        }

        current = first;
        return true;
    }
 

    public boolean setLast () {

        if (isEmpty()) {
            return false;
        }

        current = last;
        return true;
    }



    public boolean getNext () {
        
        if (current == last) {
            return false;
        }
        current = current.next;
        return true;
    }


    public boolean getPrior () {

        if (current == first) {
            return false;
        }
        current = current.prior;
        return true;
    }


    public boolean equals(Object rhs) {
        if (!(rhs instanceof Lijst)) {
            return false;
        }

        Lijst lijst = (Lijst) rhs;
        if (lijst.size() != size()) {
            return false;
        }
        
        Knoop thisCurrent = first;
        Knoop rhsCurrent = lijst.first;
        
        while (thisCurrent != null) {
            if (!thisCurrent.equals(rhsCurrent)) {
                return false;
            }
            thisCurrent = thisCurrent.next;
            rhsCurrent = rhsCurrent.next;
        }

        return true;

    }

    
    public Object clone() throws CloneNotSupportedException {

        Lijst lijst = (Lijst) super.clone();   
        lijst.size = 0;

        Knoop thisCurrent = first;
        Knoop rhsCurrent = null;

        while (thisCurrent != null) {
            lijst.insert((Data) thisCurrent.data.clone());
            if (thisCurrent == current) {
                rhsCurrent = lijst.current;
            }
            thisCurrent = thisCurrent.next;
        }
     
        lijst.current = rhsCurrent;

        return lijst;

    }

    public String toString() {

        Knoop k = first;
        String result = "";

        while (k != null) {
            result += k.data.toString();
            k = k.next;
        }
     
        return result;
    }

}
