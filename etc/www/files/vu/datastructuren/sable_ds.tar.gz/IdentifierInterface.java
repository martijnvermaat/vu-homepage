public interface IdentifierInterface extends Data {


    /*
      Elements  : Alphanumeric characters of type [char]
      Structure : Linear
      Domain    : Contains at least [MIN_NUM_ELEMENTS] elements and first element is a letter
    */


    static final int MIN_NUM_ELEMENTS = 1;


    /*

      Constructors


      Identifier();
      PRE  -
      POST - New [Identifier] object is created

      Identifier(char c);
      PRE  - [c] is a letter
      POST - New [Identifier] object is created with [c] as only element

    */


    Identifier init(char c);
    /*
      PRE  - [c] is a letter
      POST - [c] is only elements of [this], [this]-POST is returned.
    */

    String toString();
    /*
      PRE  -
      POST - A String representation of [this] is returned
    */

    char getChar(int index);
    /*
      PRE  - 0 <= [index] < [numberOfElements()]
      POST - Element on position [index] is returned
    */


    String getAll();
    /*
      PRE  - 
      POST - All characters are returned in order, in a String.
    */
    

    Identifier addChar(char c);
    /*
      PRE  - [c] is an alphanumeric character
      POST - [c] is added as last element of [this], [this]-POST is returned
    */

    int numberOfElements();
    /*
      PRE  -
      POST - Number of elements of [this] is returned
    */

    boolean equals(Object rhs);
    /*
      PRE  -
      POST - TRUE  : elements of [rhs] equal elements of [this] 
             FALSE : otherwise 
    */


}
