class Identifier implements IdentifierInterface {


    /*
      Elements  : Alphanumeric characters of type [char]
      Structure : Linear
      Domain    : Contains at least [MIN_NUM_ELEMENTS] elements 
                  and first element is a letter
    */


    static final int MIN_NUM_ELEMENTS = 1;
    static final char DEFAULT_CHAR = 'd';

    String identifier;



    Identifier() {
        init(DEFAULT_CHAR);
    }


    Identifier(char c) {
        init(c);
    }
     

    public Identifier init(char c) {
        identifier = ""+c;
        return this;
    }
    

    public String toString() {
        return identifier;
    }


    public char getChar(int index) {
        return identifier.charAt(index);
    }

    public String getAll() {
        return identifier;
    }


    public Identifier addChar(char c) {
        identifier += c;
        return this;
    }
    

    public int numberOfElements() {
        return identifier.length();
    }

    public boolean equals(Object rhs) {
        if(!(rhs instanceof Identifier)) {
            return false;
        }
        return identifier.equals( ((Identifier)rhs).identifier );
    }

    
    public int compareTo(Object rhs) {
        if(!(rhs instanceof Identifier)) {
            throw new ClassCastException("Identifier expected");
        }
        return identifier.compareTo( ((Identifier)rhs).identifier );
    }


    public Object clone() {
        try {
            Identifier clone = (Identifier) super.clone();
            clone.identifier = identifier;
            return clone;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }


}
