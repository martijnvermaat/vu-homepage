class Assignment implements AssignmentInterface {



    private Set set;
    private Identifier identifier;
      


    Assignment() {
        init(new Identifier(), new Set());
    }
        
    Assignment(Identifier identifier, Set set) {
        init(identifier, set);
    }
     


    public Assignment init(Identifier identifier, Set set) {
        this.set = (Set) set.clone();
        this.identifier = (Identifier) identifier.clone();
        return this;
    }

    public String toString() {
        return "Identifier: " + identifier.toString() + "Set: " + set.toString();
    }
    

    public Set getSet() {
        return (Set) set.clone();
    }
     

    public Identifier getIdentifier() {
        return (Identifier) identifier.clone();
    }

    public boolean equals(Object rhs) {
        if(!(rhs instanceof Assignment)) {
            throw new ClassCastException("Assignment expected");
        }
        Assignment ass = (Assignment) rhs;
        return identifier.equals( ass.identifier) 
               && set.equals( ass.set );

    }

    public int compareTo(Object rhs) throws ClassCastException {
        if(!(rhs instanceof Assignment)) {
            throw new ClassCastException("Assignment expected");
        }
        return identifier.compareTo( ((Assignment)rhs).identifier );
    }
        

    public Object clone() {
        try {
            Assignment clone = (Assignment) super.clone();
            clone.identifier = (Identifier) identifier.clone();
            clone.set = (Set) set.clone();
            return clone;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }

    
}
